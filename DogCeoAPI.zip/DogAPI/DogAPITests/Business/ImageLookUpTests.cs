﻿using DogAPI.Business;
using DogAPI.Models;
using DogAPI.Repositories;
using DogAPI.VendorAPI;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DogDataContext.Models;

namespace DogAPI.Tests.Business
{
    [TestClass]
    public class ImageLookUpTests
    {
        private ImageLookUp _imageLookUp;
        private Mock<IDogBreedRepository> _dogBreedRepositoryMock;
        private Mock<IDogCeoAPI> _dogCeoAPIMock;
        private Mock<ILogger<ImageLookUp>> _loggerMock;

        [TestInitialize]
        public void Setup()
        {
            _dogBreedRepositoryMock = new Mock<IDogBreedRepository>();
            _dogCeoAPIMock = new Mock<IDogCeoAPI>();
            _loggerMock = new Mock<ILogger<ImageLookUp>>();

            _imageLookUp = new ImageLookUp(_loggerMock.Object, _dogBreedRepositoryMock.Object, _dogCeoAPIMock.Object);
        }

        [TestMethod]
        public async Task LookUpImageAsync_WithExistingBreedInCache_ShouldReturnCachedBreed()
        {
            // Arrange
            string breed = "Labrador";
            DogBreed cachedBreed = new DogBreed { Breed = breed, ImageUrl = "http://example.com/labrador.jpg" };
            _dogBreedRepositoryMock.Setup(repo => repo.Retrieve(breed)).Returns(cachedBreed);

            // Act
            var result = await _imageLookUp.LookUpImageAsync(breed);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(cachedBreed.Breed, result.Breed);
            Assert.AreEqual(cachedBreed.ImageUrl, result.ImageUrl);
        }

        [TestMethod]
        public async Task LookUpImageAsync_WithNonExistingBreedInCache_ShouldFetchFromAPIAndReturnBreed()
        {
            // Arrange
            string breed = "German Shepherd";
            string apiUrl = "http://example.com/api";
            string imageUrl = "http://example.com/german-shepherd.jpg";
            DogCeoResponse dogCeoResponse = new DogCeoResponse { Message = imageUrl };
            _dogCeoAPIMock.Setup(api => api.GetDogBreedPictureAsync(breed)).ReturnsAsync(dogCeoResponse);
            _dogBreedRepositoryMock.Setup(repo => repo.Retrieve(breed)).Returns((DogBreed)null);

            // Act
            var result = await _imageLookUp.LookUpImageAsync(breed);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(breed, result.Breed);
            Assert.AreEqual(imageUrl, result.ImageUrl);
            _dogBreedRepositoryMock.Verify(repo => repo.InsertAsync(It.IsAny<DogBreed>()), Times.Once);
        }

        [TestMethod]
        public async Task LookUpImageAsync_WhenApiCallFails_ShouldThrowException()
        {
            // Arrange
            string breed = "Chihuahua";
            _dogCeoAPIMock.Setup(api => api.GetDogBreedPictureAsync(breed)).ThrowsAsync(new Exception());
            _dogBreedRepositoryMock.Setup(repo => repo.Retrieve(breed)).Returns((DogBreed)null);

            // Act & Assert
            await Assert.ThrowsExceptionAsync<Exception>(() => _imageLookUp.LookUpImageAsync(breed));
        }
    }
}