﻿using DogAPI.Models;
using DogDataContext.Models;

namespace DogAPI.Repositories
{
    public interface IDogBreedRepository
    {
        Task<DogBreed>? InsertAsync(DogBreed breed);
        DogBreed? Retrieve(string breed);
    }
}