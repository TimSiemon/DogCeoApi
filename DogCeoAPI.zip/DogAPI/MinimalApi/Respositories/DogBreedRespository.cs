using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Collections.Concurrent;
using Microsoft.EntityFrameworkCore;
using DogAPI.Business;
using DogDataContext.Models;

namespace DogAPI.Repositories
{
    public class DogBreedRepository : IDogBreedRepository
    {
        private ILogger _logger;
        private GoodDogContext _db;
        private static ConcurrentDictionary<string, DogBreed>? DogBreedCache;

        //Initializes the repository with a logger(`ILogger`) and a context for accessing the database(`GoodDogContext`).
        public DogBreedRepository(ILogger<ImageLookUp> logger, GoodDogContext db)
        {
            _logger = logger;
            _db = db;
            InitializeCache();
        }

        //Initializes a cache(`DogBreedCache`) with dog breed data from the database.
        private void InitializeCache()
        {
            // Use Interlocked.CompareExchange to ensure thread-safe initialization
            if (DogBreedCache == null)
            {
                var newCache = new ConcurrentDictionary<string, DogBreed>(_db.DogBreeds.ToDictionary(c => c.Breed));
                Interlocked.CompareExchange(ref DogBreedCache, newCache, null);
            }
        }

        //Inserts a new dog breed into the database
        public async Task<DogBreed> InsertAsync(DogBreed breed)
        {
            try
            {
                EntityEntry<DogBreed> added = await _db.DogBreeds.AddAsync(breed);
                int affected = await _db.SaveChangesAsync();

                if (affected != 1)
                {
                    throw new InvalidOperationException("Failed to insert the dog breed.");
                }

                if (DogBreedCache != null)
                {
                    // Ensure thread-safe cache update
                    lock (DogBreedCache)
                    {
                        DogBreedCache.AddOrUpdate(breed.Breed, breed, UpdateCache);
                    }
                }

                return breed;
            }
            catch (DbUpdateException ex)
            {
                // Log the exception and rethrow it
                Console.WriteLine($"Database error: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                // Log the exception and rethrow it
                Console.WriteLine($"Unexpected error: {ex.Message}");
                throw;
            }
        }

        //Updates the cache with new dog breed data.
        private DogBreed? UpdateCache(string breed, DogBreed newBreed)
        {
            if (DogBreedCache.TryGetValue(breed, out var oldBreed))
            {
                if (DogBreedCache.TryUpdate(breed, newBreed, oldBreed))
                {
                    _logger.LogInformation($"Cache updated successfully for dog breed '{breed}'.");
                    return newBreed;
                }
                else
                {
                    _logger.LogWarning($"Failed to update the cache for dog breed '{breed}'.");
                }
            }
            else
            {
                _logger.LogWarning($"Dog breed '{breed}' not found in the cache.");
            }
            return null;
        }

        //Retrieves a dog breed from the cache by its name.
        public DogBreed? Retrieve(string breed)
        {
            if (DogBreedCache.TryGetValue(breed, out var dogBreed))
            {
                return dogBreed;
            }
            return null;
        }
    }
}