﻿using DogAPI.Models;
using Microsoft.Extensions.Options;
using RestSharp;
using Newtonsoft.Json;
using DogAPI.Business;


namespace DogAPI.VendorAPI
{
    //Service for interacting with the Dog Ceo API.
    public class DogCeoAPI : IDogCeoAPI
    {
        private readonly ILogger _logger;
        private readonly IAppSettings _appSettings;
        private readonly string ApiBaseUrl;
        private readonly IRestClient _restClient;

        //Constructor
        public DogCeoAPI(ILogger<ImageLookUp> logger, IOptions<AppSettings> appSettings, IRestClient restClient)
        {
            _logger = logger;
            _appSettings = appSettings.Value;
            ApiBaseUrl = _appSettings.Vendor.API.DogCeoApiUrl;
            _restClient = restClient;
        }

        // Fetches a random dog breed image URL.
        public async Task<DogCeoResponse> GetDogBreedPictureAsync(string breedName)
        {
            try
            {
                var request = new RestRequest($"{ApiBaseUrl}breed/{breedName}/images/random", Method.Get);
                var response = await _restClient.ExecuteAsync(request).ConfigureAwait(false);

                DogCeoResponse dogCeoResponse = JsonConvert.DeserializeObject<DogCeoResponse>(response.Content);

                if (!response.IsSuccessful)
                {
                    throw new HttpRequestException($"{dogCeoResponse.Message}: {response.StatusCode}");
                }

                if (dogCeoResponse == null)
                {
                    throw new JsonSerializationException("Failed to deserialize the response content.");
                }

                return dogCeoResponse;
            }

            //Exceptions are logged using the provided logger (`ILogger`).
            catch (HttpRequestException ex)
            {
                _logger.LogError($"Error: {ex.Message}");
                throw;
            }
            catch (JsonSerializationException ex)
            {
                _logger.LogError($"Error: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error: {ex.Message}");
                throw;
            }
        }

    }
}