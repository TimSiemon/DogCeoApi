﻿
using DogAPI.Models;

namespace DogAPI.VendorAPI
{
    public interface IDogCeoAPI
    {
        Task<DogCeoResponse> GetDogBreedPictureAsync(string breedName);
    }
}