using DogAPI;
using DogAPI.Business;
using DogAPI.Repositories;
using DogAPI.VendorAPI;
using DogDataContext.Models;
using Microsoft.EntityFrameworkCore;
using RestSharp;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/DogAPILog.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

//Serilog logging pipeline
builder.Host.ConfigureServices((hostContext, services) =>
{
    services.AddLogging(loggingBuilder =>
        loggingBuilder.AddSerilog(dispose: true));
});

//Setup Data context 
builder.Services.AddDbContext<GoodDogContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Build the configuration
var configuration = builder.Configuration;
builder.Services.Configure<AppSettings>(builder.Configuration);

//Registering various services such as repositories and API client
builder.Services.AddScoped<IDogBreedRepository, DogBreedRepository>();
builder.Services.AddScoped<IImageLookUp, ImageLookUp>();
builder.Services.AddScoped<IDogCeoAPI, DogCeoAPI>();
builder.Services.AddScoped<IRestClient, RestClient>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.MapSwagger();
app.UseSwaggerUI();

// DogBreed Endpoint
app.MapGet("/api/dogbreeds/{breed}/images", async (IImageLookUp imageLookUp, string breed, string? subbreed) =>
{
    try
    {
        string lookupKey = !string.IsNullOrWhiteSpace(subbreed) ? $"{breed}/{subbreed}" : breed;
        var results = await imageLookUp.LookUpImageAsync(lookupKey.ToLower());
        return Results.Ok(results.ImageUrl);
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "An error occurred while looking up the dog breed image.");
        // I might want to return a more specific HTTP status code here, like 500 Internal Server Error.
        return Results.NotFound(ex.Message);
    }
});

app.Run();