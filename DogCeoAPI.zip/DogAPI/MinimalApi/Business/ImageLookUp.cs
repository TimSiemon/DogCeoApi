﻿using DogAPI.Models;
using DogAPI.Repositories;
using DogAPI.VendorAPI;
using DogDataContext.Models;

namespace DogAPI.Business
{
    public class ImageLookUp : IImageLookUp
    {
        private readonly IDogBreedRepository _dogBreedRepository;
        private readonly IDogCeoAPI _dogCeoAPI;
        private ILogger _logger;

        // Constructor for dependency injection
        public ImageLookUp(ILogger<ImageLookUp> logger, IDogBreedRepository dogBreedRepository, IDogCeoAPI dogCeoAPI)
        {
            _logger = logger;
            _dogBreedRepository = dogBreedRepository ?? throw new ArgumentNullException(nameof(dogBreedRepository));
            _dogCeoAPI = dogCeoAPI ?? throw new ArgumentNullException(nameof(dogCeoAPI));
        }

        // Asynchronous method to look up a dog breed image
        public async Task<DogBreed> LookUpImageAsync(string breed)
        {
            // Attempt to retrieve the dog breed image from the cache
            var dogBreedCache = _dogBreedRepository.Retrieve(breed);

            // If the image is not in the cache, fetch it from the vendor API
            if (dogBreedCache == null)
            {
                try
                {
                    // Fetch the dog breed image from the vendor API
                    var response = await _dogCeoAPI.GetDogBreedPictureAsync(breed);

                    // Deserialize the response into a DogCeoResponse object
                    var dogCeoResponse = response;
                    //Get the image from dogCeoResponse to be cached in database
                    byte[] imageBytes = await DownloadImage(dogCeoResponse.Message);
                    // Create a new DogBreed object with the fetched image URL
                    var dogBreed = new DogBreed { Breed = breed, ImageUrl = dogCeoResponse.Message, Image = imageBytes };

                    // Insert the new DogBreed object into the repository database\caching
                    await _dogBreedRepository.InsertAsync(dogBreed);

                    // Return the DogBreed object
                    return dogBreed;
                }
                catch (Exception ex)
                {
                    // Log the exception
                    throw new Exception("Failed to retrieve dog breed image.", ex);
                }
            }

            // Return the cached DogBreed object
            return dogBreedCache;
        }

        //Asynchronously downloads an image from a given URL
        private async Task<byte[]> DownloadImage(string imageUrl)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(imageUrl);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsByteArrayAsync();
                }
                else
                {
                    throw new Exception($"Failed to download image. Status code: {response.StatusCode}");
                }
            }
        }
    }
}