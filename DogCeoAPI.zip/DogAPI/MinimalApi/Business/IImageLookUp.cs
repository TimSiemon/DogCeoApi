﻿using DogAPI.Models;
using DogDataContext.Models;

namespace DogAPI.Business
{
    public interface IImageLookUp
    {
        Task<DogBreed> LookUpImageAsync(string breed);
    }
}