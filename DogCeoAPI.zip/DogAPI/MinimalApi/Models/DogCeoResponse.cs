﻿namespace DogAPI.Models
{
    //Represents a response from the Dog CEO API.
    public class DogCeoResponse
    {
        public string Message { get; set; }
        public string Status { get; set; }

        public DogCeoResponse(string message, string status)
        {
            Message = message;
            Status = status;
        }

        public DogCeoResponse()
        { }
    }
}