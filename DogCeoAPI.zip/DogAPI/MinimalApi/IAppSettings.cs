﻿namespace DogAPI
{
    public interface IAppSettings
    {
        string AllowedHosts { get; set; }
        Connectionstrings ConnectionStrings { get; set; }
        Kestrel Kestrel { get; set; }
        Logging Logging { get; set; }
        Vendor Vendor { get; set; }
    }
}