﻿namespace DogAPI
{
    public class AppSettings : IAppSettings
    {
        public Connectionstrings ConnectionStrings { get; set; }

        public Logging Logging { get; set; }

        public Vendor Vendor { get; set; }

        public string AllowedHosts { get; set; }

        public Kestrel Kestrel { get; set; }
    }

    public class Connectionstrings
    {
        public string DefaultConnection { get; set; }
    }

    public class Logging
    {
        public Loglevel LogLevel { get; set; }
    }

    public class Loglevel
    {
        public string Default { get; set; }

        public string Microsoft { get; set; }

        public string MicrosoftHostingLifetime { get; set; }
    }

    public class Vendor
    {
        public API API { get; set; }
    }

    public class API
    {
        public string DogCeoApiUrl { get; set; }
    }

    public class Kestrel
    {
        public Endpoints Endpoints { get; set; }
    }

    public class Endpoints
    {
        public Https Https { get; set; }
    }

    public class Https
    {
        public string Url { get; set; }
    }
}