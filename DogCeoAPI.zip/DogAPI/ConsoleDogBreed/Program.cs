﻿using Microsoft.Extensions.Configuration;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Net.Http;
using System.Threading.Tasks;
using Colorful;
using Console = Colorful.Console;

namespace ConsoleDogBreed
{
    internal class Program
    {
        private static readonly HttpClient client = new HttpClient();
        private static IConfigurationRoot? configuration;

        private static async Task Main(string[] args)
        {
            configuration = LoadConfiguration();

            string? baseUrl = configuration.GetSection("AppSettings")["baseUrl"];
            string? defaultBreed = configuration.GetSection("AppSettings")["defaultBreed"];
            string? defaultSubBreed = configuration.GetSection("AppSettings")["defaultSubBreed"];

            if (string.IsNullOrWhiteSpace(baseUrl) || string.IsNullOrWhiteSpace(defaultBreed))
            {
                Console.WriteLine("Error: Configuration values 'baseUrl' and 'defaultBreed' are required.");
                return;
            }

            Console.WriteLine("Open images in browser? (y/n)", Color.Green);
            ConsoleKeyInfo yesNoKey;

            yesNoKey = Console.ReadKey();
            Console.WriteLine();

            while (true)
            {
                Console.WriteLine($"Default Breed: {defaultBreed}", Color.YellowGreen);
                Console.WriteLine($"Default SubBreed: {defaultSubBreed}", Color.YellowGreen);
                Console.WriteLine("Enter a subbreed (tibetan, english, bull) and press enter or just press enter", Color.Green);
                string? consoleSubBreed = Console.ReadLine()?.Trim();
                string? subbreed = string.IsNullOrWhiteSpace(consoleSubBreed) ? defaultSubBreed : consoleSubBreed;
                var requestUrl = $"{baseUrl}{defaultBreed}/images?subbreed={Uri.EscapeDataString(subbreed)}";

                try
                {
                    var response = await client.GetAsync(requestUrl);
                    response.EnsureSuccessStatusCode();
                    string? link = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(link, Color.SkyBlue);

                    if (yesNoKey.KeyChar == 'y')
                    {
                        OpenUrlInBrowser(link);
                    }
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"HTTP Request Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An unexpected error occurred: {ex.Message}");
                }
                Console.WriteLine();
                Console.WriteLine("Press any key to continue or 'q' to quit.", Color.Green);
                var key = Console.ReadKey();
                Console.WriteLine();
                if (key.KeyChar == 'q')
                {
                    break;
                }
            }
        }

        private static IConfigurationRoot LoadConfiguration()
        {
            var configBuilder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            return configBuilder.Build();
        }

        private static void OpenUrlInBrowser(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while trying to open the URL: {ex.Message}");
            }
        }
    }
}